import React from 'react';

const Index = () => {
    return (
        <>
            <h1>This is Index Page</h1>
        </>
    );
};

export default Index;